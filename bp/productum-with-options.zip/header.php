<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="yandex-verification" content="7d132f9b13f44ad6" />
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title>
  <?php //header("Last-Modified: " . get_the_modified_date('r'))?>

	<?php

if ($_SERVER['REQUEST_URI']=='/category/materials/bazaltovye-tkani') echo 'Базальтовые ткани: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-aramid') echo 'Угле-арамидный микс: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/braid') echo 'Карбоновые рукава купить: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/carbon-fibre-tape') echo 'Углеленты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/fabrics') echo 'Углеткани: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/multiaksialnye-tkani') echo 'Мультиаксиальные ткани: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/non-crimp-fabrics') echo 'Углеткань без переплетения: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/non-woven') echo 'Карбоновая вуаль: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-semi') echo 'Композитные полуфабрикаты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-semi/composite-semi-rods') echo 'Карбоновые прутки: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-starter-kit') echo 'Наборы карбон «Сделай Сам»: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/decorate-fabric') echo 'Декоративные ткани: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/dobavki') echo 'Добавки для эпоксидных смол: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/epoksidnye-klei') echo 'Эпоксидные клеи: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/fill-resins') echo 'Эпоксидные смолы для заливки: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/himostoykie-smoly') echo 'Химостойкие эпоксидные смолы: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/kolerovochnye-pasty') echo 'Колеровочные пасты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/laminating-resins') echo 'Эпоксидные смолы для ламинирования: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/ready-kit') echo 'Эпоксидные смолы - готовые комплекты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/termic-resins') echo 'Термостойкие эпоксидные смолы: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/fillers') echo 'Наполнители для смесей: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/fillers/fibrous') echo 'Волокнистые наполнители: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/fillers/spherical') echo 'Сферические наполнители: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/fillers/thixotropy-agents') echo 'Тиксотропные агенты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/gelcoat/gelcoat-gelcoat-materials') echo 'Эпоксидные гелькоуты - готовые комплекты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/glass-fabric/glass-fabric-glass-fabric') echo 'Стеклоткань: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/glass-fabric/glass-tapes') echo 'Стеклоленты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/glass-fabric/rukava') echo 'Рукава из стеклоткани купить: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/glues') echo 'Клеи: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/poliesterovye-smoly') echo 'Полиэстеровые смолы: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/sandvich') echo 'Сендвичные материалы: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/separators') echo 'Разделительные составы: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/silicone-compounds-materials') echo 'Силиконовые компаунды: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/tools') echo 'Инструменты для производства карбона: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/tools/dlya-raskroya') echo 'Инструменты для раскроя карбона: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/tools/for-mould-construction') echo 'Инструменты для изготовления форм карбона: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/tools/tools-knifes') echo 'Ножницы, ножи для карбона: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/tools/tools-laminate') echo 'Инструменты для ламинирования карбона: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology') echo 'Вакуумные технологии для производства карбона: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology/fitingi-aksessuary') echo 'Фитинги / Аксессуары: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology/germetiziruyushie-zhguty') echo 'Герметизирующие жгуты: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology/plenki') echo 'Пленки: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology/vacuum-tools-pumps') echo 'Вакуумные насосы: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology/vpityvaushie-materialy-setki') echo 'Проводящие материалы / Сетки: купить по выгодной цене в Москве';
elseif ($_SERVER['REQUEST_URI']=='/category/materials/vacuum-technology/zhertvennye-tkani-peel-ply') echo 'Жертвенные ткани / Peel ply: купить по выгодной цене в Москве';

elseif ($_SERVER['REQUEST_URI']=='/materials/ugletkan-karbon-200-gm2-plein-carbon-fabric-200-gm2-plain') echo 'Углеткань (карбон) 200 г/м², плейн / Carbon fabric 200 g/m², plain, 190229-NA-100-1S | Graphite PRO';
elseif ($_SERVER['REQUEST_URI']=='/materials/decorate-fabric/dekorativnaya-tkan-aluteks-300-gm2-design-glass-fabric-300-gm') echo 'Декоративная ткань Алютекс, 300 г/м², твилл, № 195121S / Design glass fabric 300 g/mІ² silver | Graphite PRO';
elseif ($_SERVER['REQUEST_URI']=='/materials/outlet/ugletkan-karbon-245-gm2-tvill-shirina-100-c') echo 'Углеткань (карбон) 245 г/м², твилл, ширина 100 см, № 1902351S / Carbon fabric 245 g/m² | Graphite PRO';



	elseif ($_SERVER['REQUEST_URI']=='/') {echo 'Карбон, кевлар: карбоновые изделия, углеволокно, купить  карбоновую ткань, изготовление карбоновых капотов'; $seo_desc="Компания «Graphite» предлагает  купить карбоновую ткань, занимается продажей углеволокна, изготовлением карбоновых капотов и других изделий из карбона, кевлара по конкурентным ценам";}
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/gelcoat/gelcoat-gelcoat-materials') echo 'Эпоксидные гелькоуты - готовые комплекты';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/ready-kit') echo 'Эпоксидные смолы - готовые комплекты';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/glass-fabric/rukava') echo 'Рукава из стеклоткани купить';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric/braid') echo 'Карбоновые рукава купить';
	elseif ($_SERVER['REQUEST_URI']=='/materials/vacuum-technology/razjem-dlya-vacuumnogo-shlanga-hose-connector-2') echo 'Разъем для вакуумного шланга Hose connector Артикул № 390142-1';
	elseif ($_SERVER['REQUEST_URI']=='/materials/vacuum-technology/fitingi-aksessuary/razjem-dlya-vacuumnogo-shlanga-hose-connector') echo 'Разъем для вакуумного шланга / Hose connector | Graphite PRO Артикул № 390150-1';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/aramid-fabric') echo 'Кевлар: купить ткань арамидную'; 
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-fabric') echo 'Углеткань, карбон, карбоновое волокно: купить углеткань в Москве';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/polyurethane-varnish') echo 'Полиуретановые лаки матовые и прозрачные продажа в Москве по низким ценам';
    // elseif ($_SERVER['REQUEST_URI']=='/technology/carbon-manufacture-2') echo '123';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-semi/composite-semi-plate') echo 'Карбоновые пластины, лист карбоновый';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/carbon-semi/composite-semi-tubes') echo 'Карбоновые трубки';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins') echo 'Эпоксидная смола, купить эпоксидную смолу прозрачную для творчества, цены в Москве';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/gelcoat') echo 'Эпоксидный гелькоут';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/glass-fabric') echo 'Стеклоткань для тюнинга';
	elseif ($_SERVER['REQUEST_URI']=='/category/materials/prepreg') echo 'Препреги, технология препрегов, получение препрега в Москве';
	elseif ($_SERVER['REQUEST_URI']=='/category/products') echo 'Карбоновая защита картера';
	elseif ($_SERVER['REQUEST_URI']=='/products/spark-plug-carbon-cover') echo 'Карбоновый капот на заказ';
	elseif ($_SERVER['REQUEST_URI']=='/materials/carbon-fibre') echo 'Карбоновое волокно - цена, описание';
        elseif ($_SERVER['REQUEST_URI']=='/category/materials/epoxy-resins/yuvelirnie-smoly') echo 'Ювелирная смола купить в Москве, эпоксидная ювелирная смола для бижутерии по низким ценам';


	else {	
	if ( is_home() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php bloginfo('description'); ?><?php } ?>
	<?php if ( is_search() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;Search Results<?php } ?>
	<?php if ( is_author() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;Author Archives<?php } ?>
	<?php if ( is_single() ) { ?><?php wp_title(''); ?>&nbsp;|&nbsp;<?php bloginfo('name'); ?><?php } ?>
	<?php if ( is_page() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php wp_title(''); ?><?php } ?>
	<?php if ( is_category() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;<?php single_cat_title(); ?><?php } ?>
	<?php if ( is_month() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;Archive&nbsp;|&nbsp;<?php the_time('F'); ?><?php } ?>
	<?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><?php bloginfo('name'); ?>&nbsp;|&nbsp;Tag Archive&nbsp;|&nbsp;<?php  single_tag_title("", true); } } 
	}
	?>
    </title>
	<?php if ($seo_desc) { 	?><meta name="description" content="<? echo $seo_desc;?> " /><?php } ?>

	<?php wp_head(); ?>
    <?php if ( is_single() ) wp_enqueue_script( 'comment-reply' ); ?>
    
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory'); ?>/960.css" media="all" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory'); ?>/style.css" media="all" />

<link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/js/magnific-popup/magnific-popup.css">
<script src="<?php echo get_template_directory_uri();?>/js/magnific-popup/jquery.magnific-popup.min.js"></script>
<!-- /home/jetfire/www/graphite-pro.dev/wp-content/themes/productum/js/magnific-popup/jquery.magnific-popup.min.js -->
	<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_directory'); ?>/ie.css" /><![endif]-->
    <!--[if lt IE 7]>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/js/pngfix.js"></script>
	<![endif]-->
	
<!--	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/includes/js/animatedcollapse.js">

	/***********************************************
	* Animated Collapsible DIV v2.0- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
	* This notice MUST stay intact for legal use
	* Visit Dynamic Drive at http://www.dynamicdrive.com/ for this script and 100s more
	***********************************************/

	</script> -->
	
	<script type="text/javascript">
// animatedcollapse.addDiv('info_order', 'hide=1');
// animatedcollapse.init();
</script>
	
	<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon.ico" /> 

<!-- СЛАЙДШОУ -->

        <?php if ( is_home() or is_front_page() or is_page()) : ?>
<?php wp_enqueue_script('jquery'); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.cycle.all.min.js"></script>
        <script type="text/javascript">
            (function($) {
                $(function() {
                    $('#slide_sid').cycle({
                        fx:     'fade',
                        timeout: 5000
                    });
                })
            })(jQuery)
        </script>
<script src="<?php bloginfo('template_url'); ?>/js/jquery.PrintArea.js" type="text/JavaScript" language="javascript"></script>
        <script type="text/javascript">
            jQuery(document).ready(function(){
                jQuery("#print_link").click(function(){
                  var mode = 'iframe';
                    var options = { mode : mode, popClose : close };
                    jQuery("#main").printArea( options );
                });
            });
        </script>
        <?php endif; ?>
<!-- СЛАЙДШОУ END -->
<!-- Google Analytics -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-20409917-1']);
  _gaq.push(['_addOrganic', 'top-page.ru', 'q']);
  _gaq.push(['_addOrganic', 'nigma.ru', 's']);
  _gaq.push(['_addOrganic', 'webalta.ru', 'q']);
  _gaq.push(['_addOrganic', 'ru.alhea.com', 'q']);
  _gaq.push(['_addOrganic', 'delta-search.com', 'q']);
  _gaq.push(['_addOrganic', 'images.yandex.ru', 'text', true]);  
  _gaq.push(['_addOrganic', 'blogsearch.google.ru', 'q', true]);
  _gaq.push(['_addOrganic', 'blogs.yandex.ru', 'text', true]);
  _gaq.push(['_addOrganic', 'search.skydns.ru', 'query']);
  _gaq.push(['_addOrganic', 'gigabase.ru', 'q']);
  _gaq.push(['_addOrganic', 'search.globososo.com', 'q']);
  _gaq.push(['_addOrganic', 'search.tut.by', 'query']);
  _gaq.push(['_addOrganic', 'searchfunmoods.com', 'q']);
  _gaq.push(['_addOrganic', 'search.qip.ru', 'query']);
  _gaq.push(['_addOrganic', 'search.ukr.net', 'q']);
  _gaq.push(['_addOrganic', 'start.iminent.com', 'q']);
  _gaq.push(['_addOrganic', 'mysearchresults.com', 'q']);
  _gaq.push(['_addOrganic', 'searchya.com', 'q']);
  _gaq.push(['_addOrganic', 'search.mywebsearch.com', 'searchfor']);
  _gaq.push(['_addOrganic', 'poisk.ru', 'text']);
  _gaq.push(['_addOrganic', 'quintura.ru', 'request']);
  _gaq.push(['_addOrganic', 'start.facemoods.com', 'q']);
  _gaq.push(['_addOrganic', 'search.smartaddressbar.com', 's']); 
  _gaq.push(['_addOrganic', 'all.by', 'query']);
  _gaq.push(['_addOrganic', 'search.i.ua', 'q']);
  _gaq.push(['_addOrganic', 'meta.ua', 'q']);
  _gaq.push(['_addOrganic', 'index.online.ua', 'q']);
  _gaq.push(['_addOrganic', 'web20.a.ua', 'query']);
  _gaq.push(['_addOrganic', 'search.babylon.com', 'q']);
  _gaq.push(['_setSiteSpeedSampleRate', 5]); 
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- /Google Analytics -->
<link href="https://fonts.googleapis.com/css?family=Rajdhani" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/fonts/fontello/css/fontello.css" />
<!--[if gte IE 9]> <style type="text/css">  .gradient {  filter: none;} </style><![endif]-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.1/jquery.fancybox.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.1/jquery.fancybox.min.js"></script>

</head>

<body<?php if ( is_front_page() ) { ?> id="home"<?php } ?> class="custom">

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter11430649 = new Ya.Metrika({
                    id:11430649,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/11430649" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

	<div id="wrap">

		<ul class="skip">
			<li><a href="#nav">Skip to Navigation</a></li>
			<li><a href="#content">Skip to Content</a></li>
		</ul>

		<div id="header">
            
            <div id="logo"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/" title="Graphite PRO"><img src="http://<?php echo $_SERVER['HTTP_HOST'];?>/wp-content/themes/productum/images/logo-graphite-final.png" alt="" /></a></div> 
						<a id="tagline" style="color:#fff;font-style:normal;font-family: 'Rajdhani', sans-serif;font-size: 2.4em;padding: 10px 23px;"><span style="color:#777777">(495)</span>   721-85-59 
            <?php //<1php bloginfo('description'); ?> 
            </a>

            <span id="sid_zakaz"><a onClick="yaCounter22359052.reachGoal('oformitzakaz');" href="<?php echo get_page_link(7433); ?>"  target="_blank">Оформить заказ</a></span>
<div class="h_mail">
info@graphite-pro.ru
</div>
<div class="h_addr">
Россия, Москва,<br>ул.Сигнальный проезд д. 16 строение 21
</div>
	
        
			 <ul id="nav">
			
			<!--<#php if(is_home()) echo ' class="current_page_item"'; ?><a href="<#php bloginfo('url'); #>">Home</a></li>-->
            <?php if ( get_option('woo_blog_permalink') ) { ?><li <?php if ( is_category() || is_search() || is_single() || is_tag() || is_search() || is_archive() ) { ?> class="current_page_item" <?php } ?>><a href="<?php echo get_option('home'); echo get_option('woo_blog_permalink'); ?>" title="Blog"><span>Blog</span></a></li><?php } ?>
			<?php 
            if (get_option('woo_cat_nav')) 
                wp_list_categories('orderby=order&depth=3&title_li=&exclude='.get_option('woo_nav_exclude')); 
            else
                wp_list_pages('sort_column=menu_order&depth=3&title_li=&exclude='.get_option('woo_nav_exclude')); 
            ?>

			<li><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/training">Обучение</a></li>
			<li><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/how-to-buy">Как купить</a></li>
			<li><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/photogallery">Фотогалерея</a></li>
			<li><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/about">Контакты</a></li>
			</ul>


<?php if ( is_front_page() ) { ?>

			<div id="featuredTxt">
			
			<br />               
<!--			<p><?php echo stripslashes(get_option('woo_about_text')); ?></p> -->
			<p>Компания Graphite PRO (Графит ПРО) - это коллектив специалистов занимающихся разработкой и изготовлением  изделий из композиционных материалов с широким применением углепластика (карбона). Производимые  нами изделия изготавливаются с соблюдением технологии – формуются под высоким давлением и температурой</p>
				
			</div>

             <ul id="featuredNav">

                <?php if (get_option('woo_about_button_1')) { ?><li><a href="<?php echo get_option('woo_button_link_1'); ?>" title="Read more about me"><?php echo stripslashes(get_option('woo_about_button_1')); ?></a></li><?php } ?>
				<?php if (get_option('woo_about_button_2')) { ?><li><a href="<?php echo get_option('woo_button_link_2'); ?>" title="Read more about me"><?php echo stripslashes(get_option('woo_about_button_2')); ?></a></li><?php } ?>

			</ul>
            
            <div id="loader"></div>
				
			<div id="featuredImg">

				<p>
               <img id="featured" src="<?php bloginfo('template_directory'); ?>/images/img-featured-02.png" alt="<?php bloginfo('name'); ?>" /></a>
                
                </p>

			</div>
<?php } ?>
		</div><!-- / #header -->
		<div id="content">
		
			<?php if ( is_front_page() ) { ?>
			<?php } else { ?>
			<!-- успешная проверка на первую страницу -->
			
			
			
			<?php 
			$cats = array('3');
			$categories = get_categories('child_of=3'); 

			foreach ($categories as $cat) {
			$cats[] = $cat->cat_ID;
			}
			
			$products = array('4');
			$categories = get_categories('child_of=4'); 
			foreach ($categories as $cat) {
			$products[] = $cat->cat_ID;
			}


			if (is_category($cats) || in_category($cats)) { ?>
			
			<div id="cat_title">
          <div class="a21_wrap_cat_title"><div class="h_1">МАТЕРИАЛЫ    
         </div><div class="title_desc">для производства изделий из карбона</div></div>
         <div class="as21_username">
          <?php $cur_user = wp_get_current_user();
          // var_dump($cur_user->ID);
          if ( 0 != $cur_user->ID ) { 
             if($cur_user->user_firstname || $cur_user->user_lastname) echo 'Вы вошли как: <a href="/user-data"> '.$cur_user->user_firstname.' '.$cur_user->user_lastname.'<a/>';
           // .' '.$cur_user->user_login;
           }
          // print_r($cur_user);
          ?>
          </div>
           <div class="a21_top_cart">
                <span class="as21_mcc <?php if(!empty($_SESSION['total_count']) ) echo ' mini_cart_count'; ?>" ><?php if(!empty($_SESSION['total_count']) ) echo $_SESSION['total_count']; ?></span>
                <!--<?php if(!empty($_SESSION['total_count']) ) echo '<span class="mini_cart_count">'.$_SESSION['total_count'].'</span>'; ?>-->
                <!-- <a href="#a21_big_cart" class="a21_big-cart-popup-modal"><img src="<?php echo get_template_directory_uri()?>/images/a21/basket.gif" alt="" /></a> -->
                <!-- <a href="#a21_big_cart" class="a21_big-cart-popup-modal"><img src="<?php echo get_template_directory_uri()?>/images/a21/cart_1.png" alt="" /></a> -->
                <!-- <a href="#a21_big_cart" class="a21_big-cart-popup-modal"><img src="<?php echo get_template_directory_uri()?>/images/a21/cart_orig.png" alt="" /></a> -->
                <a href="#a21_big_cart" class="a21_big-cart-popup-modal">   <img src="<?php echo get_template_directory_uri()?>/images/a21/cart_a21.png" alt="" /></a>
                <div class="a21_wrap_cart_calc">
                <p>Количество товаров: <span id="a21_cart_count">
                <?php if(!empty($_SESSION['total_count'])) echo $_SESSION['total_count']; else echo "0";?>
                </span></p>
                <p>На сумму: <span id="a21_cart_sum"><?php if(!empty($_SESSION['total_sum'])) echo $_SESSION['total_sum']; else echo "0";?></span></p>
                </div>
           </div>
			</div>
			
			<?php } elseif (is_category($products) || in_category($products)) { ?>
			
			<div id="cat_title"><div class="h_1">ПРОДУКЦИЯ</div><div class="title_desc">нашей компании из углеволокна</div></div>
			
			<?php } else { ?>
			
					<?php if (is_page()) { ?>
					<div id="cat_title"><h1><?php wp_title(''); ?></h1></div>
					<?php } ?>
					
		
			<?php } ?>
			
			<!-- ниже окончание условия проверки на первую страницу -->

			<?php } ?>
    
      <?php if( !is_front_page() ):?>
      <div class="wrap_search_and_icons">

          <?php get_search_form(); ?>
          <div class="right-icons">
            <!-- <a class="icon logo_link laminatrechner" target="laminatrechner" href="<?php echo get_template_directory_uri().'/calc/';?> "><img src="<?php echo get_template_directory_uri();?>/images/a21/calc.svg" alt="" /></a> -->
            <a class="icon logo_link laminatrechner" target="laminatrechner" href="https://www.r-g.de/en/laminatecalculator.html"><img src="<?php echo get_template_directory_uri();?>/images/a21/calc.svg" alt="" /></a>
            <a href="/user-data" class="icon user"><img src="<?php echo get_template_directory_uri();?>/images/a21/human_head.svg" alt="" /></a>
            
  <!--          
             <a href="https://www.facebook.com/RGComposite/" class="icon icon-facebook"></a>
            <a href="https://www.youtube.com/user/RuGComposites" class="icon icon-youtube"></a>
            <a href="https://www.instagram.com/rg_faserverbund/?ref=badge" class="icon icon-instagram"></a>
   -->        
            <a href="<?php echo esc_url(get_option( 'option_facebook' ));?>" class="icon icon-facebook"></a>
            <a href="<?php echo esc_url(get_option( 'option_youtube' ));?>" class="icon icon-youtube"></a>
            <a href="<?php echo esc_url(get_option( 'option_instagram' ));?>" class="icon icon-instagram"></a>
            
            <a href="http://r-g.de/" target="_blank" class="icon logo_vendor"><img src="<?php echo get_template_directory_uri();?>/images/a21/logo_vendor2.png" alt="" /></a>
          </div>
          <div class="clear"></div>

      </div>
      <?php endif;?>
			<div id="contentWrap" class="container_16">
