		</div><!-- / #contentWrap -->
		
		</div><!-- / #content -->

		    
        <div class="container_16 clearfix">
        
        	<div class="grid_16 credits">
<style>
.podvsto {width: 100%; text-align: center;min-height: 150px;}
.podvalcat {width: 25%;float: left;}
</style>

<div class="podvsto">
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/epoxy-resins">Эпоксидные смолы</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/gelcoat">Эпоксидные гелькоуты</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/carbon-fabric">Углеткани (карбон)</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/carbon-starter-kit">Наборы карбон "Сделай Сам"</a></div>

<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/carbon-aramid">Угле-арамидный микс</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/aramid-fabric">Арамидные ткани (кевлар)</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/bazaltovye-tkani">Базальтовые ткани</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/glass-fabric">Стеклоткани</a></div>

<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/vacuum-technology">Вакуумные технологии</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/izgotovlenie-osnastki">Изготовление оснастки</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/tools">Инструменты</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/decorate-fabric">Декоративные ткани</a></div>

<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/fillers">Наполнители</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/glues">Клеи</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/separators">Разделительные составы</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/polyurethane-varnish">Полиуретановые лаки</a></div>

<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/prepreg">Препреги</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/silicone-compounds-materials">Силиконовые компаунды</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/silicone-compounds-materials">Силиконовые компаунды</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/sandvich">Сендвичные материалы</a></div>

<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/carbon-semi">Композитные полуфабрикаты</a></div>
<div class="podvalcat"><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/category/materials/poliesterovye-smoly">Полиэстеровые смолы</a></div>
</div>


<p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> All rights reserved.
<br />
<table>
<tr>
<td>
GRAPHITE PRO Композиционные Технологии<br />
Россия, Москва, ул.Сигнальный проезд д. 16 строение 21<br />
Тел.: +7 (495) 721-85-59, +7 (968) 694-61-58<br />
mail: info@graphite-pro.ru
</td>
<td>
<b>Время работы:</b><br />
10.00 до 19.00 в будние дни<br />
14.00 до 14.30 — обеденный перерыв<br />
суббота, воскресенье — выходной
</td>
</tr>
</table>
<!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href='http://www.liveinternet.ru/click' "+
"target=_blank><img src='http://counter.yadro.ru/hit?t45.4;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet' "+
"border='0' width='31' height='31'><\/a>")
//--></script><!--/LiveInternet-->

<!-- Yandex.Metrika counter -->
<div style="display:none;"><script type="text/javascript">
(function(w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter11430649 = new Ya.Metrika({id:11430649, enableAll: true});
        }
        catch(e) { }
    });
})(window, "yandex_metrika_callbacks");
</script></div>
<script src="//mc.yandex.ru/metrika/watch.js" type="text/javascript" defer="defer"></script>
<noscript><div><img src="//mc.yandex.ru/watch/11430649" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

</p>

        	</div><!-- / #credits -->
		</div><!-- / #container_16 -->
    	
	</div><!-- / #wrap -->
    
    <?php wp_footer(); ?>
    <?php //echo "-----------".__FILE__; ?>
    <br>
    <br>
	<?php if ( get_option('woo_google_analytics') <> "" ) { echo stripslashes(get_option('woo_google_analytics')); } ?>

	<script type="text/javascript">
    <!--//--><![CDATA[//><!--
        var clear = "<?php bloginfo('template_url'); ?>/img/blank.gif";
        var loading = "<?php bloginfo('template_url'); ?>/img/loading.gif";
    //-->!]]>
    </script>
    <script type="text/javascript" src="<?php bloginfo('template_url') ?>/includes/js/setup.imgswitch.js"></script>
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'ZHcrGS3wJU';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
<!-- {/literal} END JIVOSITE CODE -->

<script src="<?php echo get_template_directory_uri();?>/js/a21-scripts.js" type="text/javascript"></script>



<div id="add_product_to_cart" class="white-popup-block mfp-hide">
    <h1>Товар добавлен в корзину</h1>
    <p class="a21_mfp_left"></p>
    <p class="a21_mfp_right"></p>
    <div class="clear"></div>
        <a href="#" id="continue_buy">Продолжить покупки</a>
        <!-- <a href="#" id="a21_oformit_zakaz" class="product-buy">Оформить заказ</a> -->
    <!-- <p><a class="popup-modal-dismiss" href="#">Dismiss</a></p> -->
</div>


<div id="a21_big_cart" class="white-popup-block mfp-hide">
    <span class="popup-modal-dismiss">x</span>
    <h1>Корзина</h1>
    <div class="wrap_cart_prod"></div>
<!--    <table>
        <tr>
            <td></td><td>Название</td><td>Цена</td><td>Кол-во</td><td>Сумма</td><td></td>
        </tr>
        <tr>
            <td><img src="http://graphite-pro.dev/wp-content/uploads/2016/10/y2klay.jpg" alt="Промышленный  пластилин Y2-Klay для ЧПУ" class="product_img"></td>
            <td> <a class="black_link" href="/catalog/20090">Индивидуальные номера на электромобиль</a></td>
            <td>1 500 р.</td>
            <td>
            <input style="width: 20px; text-align: center;" onkeyup="javascript: fChangeCount(47512,20090)" id="count_20090" class="cart_input" type="text" value="1">
            </td>
            <td>5 999 р.</td>
            <td></td>
        </tr>
    </table>
 -->

</div>

<a href="#a21_form_oformit_zakaz" class="go_form_oformit_zakaz">Оформить заказ</a>

<?php $cur_user = wp_get_current_user();
// var_dump($cur_user->ID);
if ( 0 != $cur_user->ID ) { 

        global $wpdb;
        $phone = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id=%d AND meta_key= %s" ,$cur_user->ID,'phone1') );
        // deb_last_query();
    
    // var_dump($phone);
}
?>

<div id="a21_form_oformit_zakaz" class="white-popup-block mfp-hide">
    <span class="popup-modal-dismiss">x</span>
    <h1>Оформить заказ</h1> 
    <div class="wrap_cart_prod"></div>
    <form>
    <table>
        <tr><td>Имя<span class="req">*</span></td><td><input type="text" name="name" value="<?php if($cur_user->user_firstname) echo $cur_user->user_firstname;?>" ></td></tr>
        <tr><td>Телефон<span class="req">*</span></td><td><input type="text" name="phone" value="<?php echo $phone;?>"></td></tr>
        <tr><td>E-mail<span class="req">*</span></td><td><input type="text" name="mail" value="<?php if($cur_user->user_email) echo $cur_user->user_email;?>"></td></tr>
        <tr><td>Комментарий</td><td><textarea name="comment"></textarea></tr>
        <?php $cur_user_id = get_current_user_id() ? get_current_user_id() : 0; ?>
        <input type="hidden" name="user_id" value="<?php echo $cur_user_id;?>">
    </table>
    <input type="submit" value="Отправить" class="product-buy" id="btn_send_from_oform_zakaz">
    <?php //print_r($_SESSION);?>
    </form>

</div>
<?php
 // print_r($_SESSION);
// echo 'phone1';

// var_dump(wpmem_gettext('phone1'));
// var_dump(wpmem_fields());
// global $wpmem;
// var_dump( wpmem_get( 'user_login' ));
// var_dump( wpmem_get( 'phone1' ));
// var_dump( $wpmem->user );
// print_r($cur_user);
// var_dump($cur_user->user_firstname);

?>
</body>
</html>
