	<div id="sidebar2" class="grid_4 home_sidebar">
<?/*
			<h3 style="margin-top:11px;">Новинки продукции<br><font style="font-size:12px">из углеволокна</font></h3>
			
			<?php query_posts('cat=4&showposts=5&orderby=rand'); ?> 
							<?php while (have_posts()) : the_post(); ?>
							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<img src="<?php echo bloginfo('template_url'); ?>/scripts/timthumb.php?src=<?php echo get_option('home'); ?>/<?php echo post_custom('Image1');?>&w=200&h=110&zc=1&q=65" alt="<?php the_title(); ?>" class="products_img" style="margin:0" width="200px" height="110px"></a>
							<h4 style="margin:0"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h4>
							<br><?php endwhile; ?>
			
			<?php if (get_option('woo_show_mostcommented')){ include(TEMPLATEPATH . '/includes/popular.php'); } ?>
            
            <!-- Add you sidebar manual code here to show above the widgets -->

            <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar(2) )  ?>		           

			<!-- Add you sidebar manual code here to show below the widgets -->
*/?>
	</div><!-- / #sidebar2 -->
			