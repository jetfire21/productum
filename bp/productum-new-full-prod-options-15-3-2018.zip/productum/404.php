<?php get_header(); ?>
			
			<div id="main" class="grid_8">

				<h2>Ошибка 404</h2>

				<p>Страница не найдена!</p>

			</div><!-- / #main -->

<?php get_sidebar(); ?>
<?php get_sidebar("2"); ?>
<?php get_footer(); ?>